// /// <reference types="vite/client" />
// No declaramos 'process' aquí para evitar conflictos con @types/node
